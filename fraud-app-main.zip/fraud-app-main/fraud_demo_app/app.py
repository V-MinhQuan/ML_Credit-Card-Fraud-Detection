import os
import io
import pickle
from datetime import datetime

import numpy as np
import pandas as pd
import joblib
import streamlit as st


# =========================
# PAGE CONFIG
# =========================
st.set_page_config(page_title="Hệ thống phát hiện gian lận thẻ tín dụng", page_icon="💳", layout="wide")

# =========================
# STYLE (CSS)
# =========================
st.markdown(
    """
    <style>
        .main-title {
            text-align: center;
            font-size: 34px;
            font-weight: 800;
            letter-spacing: 0.5px;
            margin-top: 8px;
            margin-bottom: 0px;
        }
        .sub-title {
            text-align: center;
            font-size: 15px;
            opacity: 0.85;
            margin-top: 8px;
            margin-bottom: 18px;
        }
        .upload-box {
            border: 2px dashed rgba(255,255,255,0.25);
            border-radius: 16px;
            padding: 22px;
            background: rgba(255,255,255,0.04);
            margin-top: 8px;
            margin-bottom: 18px;
        }
        .big-label {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .hint {
            opacity: 0.8;
            font-size: 13px;
        }
        .section-title {
            font-size: 20px;
            font-weight: 800;
            margin-top: 8px;
            margin-bottom: 8px;
        }
        .pill {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 999px;
            background: rgba(255,255,255,0.08);
            font-size: 12px;
            margin-right: 8px;
        }
        .divider {
            height: 1px;
            background: rgba(255,255,255,0.12);
            margin: 14px 0;
        }
    </style>
    """,
    unsafe_allow_html=True
)

st.markdown('<div class="main-title">HỆ THỐNG PHÁT HIỆN GIAN LẬN THẺ TÍN DỤNG</div>', unsafe_allow_html=True)

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model_artifacts")


# =========================
# LOAD ARTIFACTS
# =========================
@st.cache_resource
def load_artifacts(model_dir: str):
    model = joblib.load(os.path.join(model_dir, "xgb_model.joblib"))
    scaler = joblib.load(os.path.join(model_dir, "scaler.joblib"))

    with open(os.path.join(model_dir, "feature_names.pkl"), "rb") as f:
        feature_names = pickle.load(f)

    return model, scaler, list(feature_names)


def read_file(uploaded) -> pd.DataFrame:
    name = uploaded.name.lower()
    content = uploaded.getvalue()

    if name.endswith(".csv"):
        try:
            return pd.read_csv(io.BytesIO(content))
        except Exception:
            return pd.read_csv(io.BytesIO(content), encoding="latin1")
    if name.endswith(".xlsx") or name.endswith(".xls"):
        return pd.read_excel(io.BytesIO(content))

    raise ValueError("Chỉ hỗ trợ CSV hoặc Excel.")


def prepare_features(df: pd.DataFrame, feature_names: list[str]) -> pd.DataFrame:
    df = df.copy()

    missing = [c for c in feature_names if c not in df.columns]
    if missing:
        raise ValueError(f"File thiếu các cột bắt buộc: {missing}")

    X = df[feature_names].copy()

    # ép numeric
    for c in feature_names:
        X[c] = pd.to_numeric(X[c], errors="coerce")

    # fill NaN bằng median (nếu median nan -> 0)
    for c in feature_names:
        med = X[c].median()
        if np.isnan(med):
            med = 0.0
        X[c] = X[c].fillna(med)

    return X


def risk_level(p: float) -> str:
    if p >= 0.9:
        return "RẤT CAO"
    if p >= 0.7:
        return "CAO"
    if p >= 0.5:
        return "TRUNG BÌNH"
    if p >= 0.3:
        return "THẤP"
    return "RẤT THẤP"


model, scaler, FEATURE_NAMES = load_artifacts(MODEL_DIR)

# =========================
# SIDEBAR (đơn giản, hướng nghiệp vụ)
# =========================
with st.sidebar:
    st.header("⚙️ Thiết lập cảnh báo")
    threshold = st.slider("Ngưỡng gắn cờ ", 0.0, 1.0, 0.5, 0.01)

    st.divider()
    st.write("📌 **Yêu cầu file upload**")

    with st.expander("Xem danh sách cột hệ thống yêu cầu"):
        st.dataframe(pd.DataFrame({"feature_name": FEATURE_NAMES}), use_container_width=True)

# =========================
# UPLOAD CENTER (nổi bật)
# =========================
left, mid, right = st.columns([1, 2, 1])

with mid:
    st.markdown('<div class="upload-box">', unsafe_allow_html=True)
    st.markdown('<div class="big-label">📤 TẢI FILE GIAO DỊCH </div>', unsafe_allow_html=True)
    st.markdown('<div class="hint">Hỗ trợ CSV / Excel. Hệ thống sẽ chấm điểm và gắn cờ giao dịch nghi gian lận.</div>', unsafe_allow_html=True)

    uploaded = st.file_uploader(
        " ",
        type=["csv", "xlsx", "xls"],
        label_visibility="collapsed"
    )
    st.markdown("</div>", unsafe_allow_html=True)

if uploaded is None:
    st.info("Vui lòng tải file giao dịch để hệ thống bắt đầu xử lý.")
    st.stop()

# =========================
# PROCESS
# =========================
try:
    df = read_file(uploaded)
except Exception as e:
    st.error(f"Không đọc được file: {e}")
    st.stop()

# Nút xử lý rõ ràng
col_btn1, col_btn2, col_btn3 = st.columns([1, 1, 1])
with col_btn2:
    run = st.button("🚀 CHẤM ĐIỂM ", use_container_width=True)

if not run:
    st.warning("Nhấn nút **CHẤM ĐIỂM** để hệ thống chạy.")
    st.stop()

# =========================
# SCORING
# =========================
try:
    X = prepare_features(df, FEATURE_NAMES)
except Exception as e:
    st.error(str(e))
    st.stop()

X_scaled = scaler.transform(X.values)
proba = model.predict_proba(X_scaled)[:, 1]
pred = (proba >= threshold).astype(int)

scored = df.copy()
scored["fraud_probability"] = proba
scored["is_fraud"] = pred
scored["risk_level"] = [risk_level(float(p)) for p in proba]
scored["scored_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

flagged = scored[scored["is_fraud"] == 1].sort_values("fraud_probability", ascending=False)

# =========================
# RESULT SUMMARY (RÕ RÀNG)
# =========================
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-title">✅ KẾT QUẢ</div>', unsafe_allow_html=True)

total = len(scored)
flag_n = int(scored["is_fraud"].sum())
rate = (flag_n / total) if total else 0.0

pills = (
    f'<span class="pill">Tổng giao dịch: <b>{total}</b></span>'
    f'<span class="pill">Bị gắn cờ: <b>{flag_n}</b></span>'
    f'<span class="pill">Tỷ lệ gắn cờ: <b>{rate:.2%}</b></span>'
    f'<span class="pill">Ngưỡng gắn cờ: <b>{threshold:.2f}</b></span>'
)
st.markdown(pills, unsafe_allow_html=True)

c1, c2, c3 = st.columns(3)
c1.metric("Tổng giao dịch", total)
c2.metric("Giao dịch nghi gian lận", flag_n)
c3.metric("Tỷ lệ nghi gian lận", f"{rate:.2%}")

# =========================
# TABS: Flagged / All / Preview
# =========================
tab1, tab2, tab3 = st.tabs(["🚨 Danh sách nghi gian lận", "📋 Toàn bộ giao dịch", "🔍 Xem nhanh file đầu vào"])

with tab1:
    st.subheader("🚨 Danh sách giao dịch bị gắn cờ")
    if flagged.empty:
        st.success("Không phát hiện giao dịch nào vượt ngưỡng cảnh báo hiện tại.")
    else:
        min_risk = st.selectbox(
            "Lọc theo mức rủi ro tối thiểu",
            options=["RẤT THẤP", "THẤP", "TRUNG BÌNH", "CAO", "RẤT CAO"],
            index=2
        )
        order = ["RẤT THẤP", "THẤP", "TRUNG BÌNH", "CAO", "RẤT CAO"]
        flagged_view = flagged.copy()
        flagged_view["risk_rank"] = flagged_view["risk_level"].apply(lambda x: order.index(x))
        flagged_view = flagged_view[flagged_view["risk_rank"] >= order.index(min_risk)]
        flagged_view = flagged_view.drop(columns=["risk_rank"])

        st.dataframe(flagged_view.head(500), use_container_width=True)

with tab2:
    st.subheader("📋 Toàn bộ giao dịch sau khi chấm điểm")
    st.dataframe(scored.head(500), use_container_width=True)
    st.caption("Tải bản đầy đủ bên dưới.")

with tab3:
    st.subheader("🔍 Xem nhanh dữ liệu đầu vào")
    st.write("Kích thước:", df.shape)
    st.dataframe(df.head(50), use_container_width=True)

# =========================
# DOWNLOADS (RÕ + NỔI BẬT)
# =========================
st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-title">⬇️ TẢI FILE KẾT QUẢ</div>', unsafe_allow_html=True)

ts = datetime.now().strftime("%Y%m%d_%H%M%S")
col_d1, col_d2 = st.columns(2)

with col_d1:
    st.download_button(
        "⬇️ Toàn bộ giao dịch",
        data=scored.to_csv(index=False).encode("utf-8-sig"),
        file_name=f"scored_{ts}.csv",
        mime="text/csv",
        use_container_width=True
    )

with col_d2:
    st.download_button(
        "⬇️ Danh sách gian lận",
        data=flagged.to_csv(index=False).encode("utf-8-sig"),
        file_name=f"flagged_{ts}.csv",
        mime="text/csv",
        use_container_width=True
    )
